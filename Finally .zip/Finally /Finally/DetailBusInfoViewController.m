//
//  DetailBusInfoViewController.m
//  Finally
//
//  Created by Minh on 3/11/15.
//  Copyright (c) 2015 minh. All rights reserved.
//

#import "DetailBusInfoViewController.h"
#import "UILabel+dynamicSizeMe.h"

@interface DetailBusInfoViewController ()

@end
@implementation DetailBusInfoViewController {
    NSArray * arrayData;
    NSInteger selectedIndex;
    NSInteger prevIndex;
}
- (void)viewDidLoad
{
    [super viewDidLoad];
    self.automaticallyAdjustsScrollViewInsets = NO;
    arrayData = [[NSArray alloc]initWithObjects:self.myDBAttribute.info_arrivalRoute,self.myDBAttribute.info_departureRoute, nil];
    NSString * str = [NSString stringWithFormat:@"Tuyến Bus %@",self.myDBAttribute.info_vehicleID];
    self.title = str;
    self.lbl_company.text = self.myDBAttribute.info_company;
    [self.lbl_company resizeToFit];
    self.lbl_fare.text = [NSString stringWithFormat:@"%d",self.myDBAttribute.info_fare];
    self.lbl_freq.text = self.myDBAttribute.info_frequency;
    self.lbl_schedule.text = self.myDBAttribute.info_timetable;
    [self.lbl_schedule resizeToFit];
    self.lbl_route.text = self.myDBAttribute.info_route;
    [self.lbl_route resizeToFit];
    self.lbl_arrival.text = self.myDBAttribute.info_arrivalRoute;
    self.lbl_departure.text = self.myDBAttribute.info_departureRoute;
    
    [self.lbl_arrival setBackgroundColor:[UIColor whiteColor]];
    [self.lbl_departure setBackgroundColor:[UIColor whiteColor]];
    [self.lbl_departure setTextColor:[UIColor redColor]];
    [self.lbl_arrival resizeToFit];
    [self.lbl_departure resizeToFit];
//    [self.scrollView setBackgroundColor:[UIColor colorWithRed:0.6 green:0.9001 blue:0.4 alpha:1]];
//    self.view.backgroundColor = [UIColor colorWithRed:0.6 green:0.9001 blue:0.4 alpha:1];
}

- (void) viewWillAppear:(BOOL)animated{
    [self.lbl_arrival resizeToFit];
    CGRect frame1 = self.lbl_x.frame;
    frame1.origin.y = self.lbl_arrival.frame.origin.y + self.lbl_arrival.frame.size.height + 1;
    self.lbl_x.frame = frame1;
    CGRect frame2 = self.lbl_departure.frame;
    frame2.origin.y = self.lbl_x.frame.origin.y + self.lbl_x.frame.size.height;
    self.lbl_departure.frame = frame2;
    [self.lbl_departure resizeToFit];
    _scrollView.backgroundColor = [UIColor whiteColor];
    _scrollView.contentSize = CGSizeMake(320, self.lbl_departure.frame.origin.y + self.lbl_departure.frame.size.height+10);
}
@end
