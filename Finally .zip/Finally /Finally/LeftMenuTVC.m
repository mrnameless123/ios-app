//
//  LeftMenuTVC.m
//  testProject
//
//  Created by artur on 2/14/14.
//  Copyright (c) 2014 artur. All rights reserved.
//

#import "LeftMenuTVC.h"
#import "LeftTableViewCell.h"
#import "FirstVC.h"
#import "SecondVC.h"
#import "ThirdVC.h"
#import "FourthVC.h"
#import "FifthVC.h"
@interface LeftMenuTVC ()

@end

@implementation LeftMenuTVC

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.

    // Initilizing data souce
    self.tableData = [@[@"Tìm Kiếm",@"Tra Cứu Thông Tin Xe Bus",@"Tra Cứu Điểm Dừng Xe Bus",@"Tìm Kiếm Điểm Bán Vé",@"Lịch sử"] mutableCopy];
}

#pragma mark - TableView Datasource
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [self.tableData count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    static NSString * identify = @"Cell";
    LeftTableViewCell * cell = (LeftTableViewCell *) [tableView dequeueReusableCellWithIdentifier:identify];
    if (cell == nil) {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"LeftTableViewCell" owner:self options:nil];
        cell= [nib objectAtIndex:0];
    }
    cell.lbl_content.text = self.tableData[indexPath.row];
    cell.myImage.image   = [UIImage imageNamed:@"final.png"];
    return cell;

}
#pragma mark - TableView Delegate
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    UINavigationController *nvc;
    UIViewController *rootVC;
    switch (indexPath.row) {
        case 0:
        {
            rootVC = [[FirstVC alloc] initWithNibName:@"FirstVC" bundle:nil];
        }
            break;
        case 2:
        {
            rootVC = [[SecondVC alloc] initWithNibName:@"SecondVC" bundle:nil];
        }
            break;
        case 1:
        {
            rootVC = [[ThirdVC alloc] initWithNibName:@"ThirdVC" bundle:nil];
        }
            break;
        case 3:
        {
            rootVC = [[FourthVC alloc] initWithNibName:@"FourthVC" bundle:nil];
        }
            break;
        case 4:
        {
            rootVC = [[FifthVC alloc] initWithNibName:@"FifthVC" bundle:nil];
        }
            break;
        default:
            break;
    }
    nvc = [[UINavigationController alloc] initWithRootViewController:rootVC];
    
    [self openContentNavigationController:nvc];
}

@end
