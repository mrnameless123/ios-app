//
//  FourthVC.h
//  Finally
//
//  Created by Minh on 3/11/15.
//  Copyright (c) 2015 minh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FourthVC : UIViewController<UITableViewDataSource, UITableViewDelegate, UISearchDisplayDelegate>
@property (strong, nonatomic) IBOutlet UITableView *myTableView;
@property (strong, nonatomic) IBOutlet UISearchBar *searchBarController;

@property (strong, nonatomic) NSArray * SearchResult;
@property (nonatomic, strong) UIMenuController *searchController;
@end
