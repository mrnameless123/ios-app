//
//  AccessDB.m
//  Given Data
//
//  Created by Minh on 2/11/15.
//  Copyright (c) 2015 Minh. All rights reserved.
//

#import "AccessDB.h"
#import "DBAttributes.h"
@implementation AccessDB
+(NSString *) getDBPath {
    NSArray * paths= NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString * documentDir = [paths objectAtIndex:0];
    NSString * path = [documentDir stringByAppendingPathComponent:@"thesis.sql"];
    return path;
}
+(void) copyDatabaseIfNeeded{
    NSFileManager * fileManager = [NSFileManager defaultManager];
    NSError *error = nil;
    NSString *dbPath = [AccessDB getDBPath];
    BOOL success = [fileManager fileExistsAtPath:dbPath];
    if(!success) {
        NSString *defaultDBPath = [[NSBundle mainBundle] pathForResource:@"thesis" ofType:@"sql"];
//        NSString *defaultDBPath = [[[NSBundle mainBundle] resourcePath] stringByAppendingPathComponent:@"thesis.sql"];
        success = [fileManager copyItemAtPath:defaultDBPath toPath:dbPath error:&error];
        error=nil;
        if (!success)
            NSAssert1(0, @"Failed to find writable database file with message '%@'.", [error localizedDescription]);
    }

}
-(NSArray *) getBusStop {
    sqlite3 *database;
    sqlite3_open([[AccessDB getDBPath] UTF8String], &database);
    NSMutableArray *result = [[NSMutableArray alloc]init] ;
    
    NSString *sql = @"SELECT * FROM Stop";
    sqlite3_stmt * statement;
    
    int sqlResult = sqlite3_prepare_v2(database, [sql UTF8String], -1, &statement, NULL);
    
    if(sqlResult == SQLITE_OK)
    {
        
        while(sqlite3_step(statement) == SQLITE_ROW)
        {
            
        DBAttributes *p = [[DBAttributes alloc] init];
        p.stop_ID = sqlite3_column_int(statement, 0);
        p.stop_name =   ((char *)sqlite3_column_text(statement, 1)) ? [NSString stringWithUTF8String:(char *)sqlite3_column_text(statement, 1)]: nil;
        p.info_vehicleID = ((char *)sqlite3_column_text(statement, 2)) ? [NSString stringWithUTF8String:(char *)sqlite3_column_text(statement, 2)]: nil;
            [result addObject: p];
        }
    } else
    {
        result = nil;
        printf( "could not prepare statemnt: %s\n", sqlite3_errmsg(database) );
    }
    
    sqlite3_reset(statement);
    sqlite3_finalize(statement);
    
    sqlite3_close(database);
    
    return result;
}
-(NSMutableArray *) getBusInfo {
    sqlite3 *database;
    sqlite3_open([[AccessDB getDBPath] UTF8String], &database);
    NSMutableArray *result = [[NSMutableArray alloc]init] ;
    
    NSString *sql = @"SELECT * FROM ShowBusInfo";
    sqlite3_stmt * statement;
    
    int sqlResult = sqlite3_prepare_v2(database, [sql UTF8String], -1, &statement, NULL);
    
    if(sqlResult == SQLITE_OK)
    {
        while(sqlite3_step(statement) == SQLITE_ROW)
        {
            
            DBAttributes *p = [[DBAttributes alloc] init];
            p.info_vehicleID = ((char *)sqlite3_column_text(statement, 0)) ? [NSString stringWithUTF8String:(char *)sqlite3_column_text(statement, 0)]: nil;
            p.info_company = ((char *)sqlite3_column_text(statement, 1)) ? [NSString stringWithUTF8String:(char *)sqlite3_column_text(statement, 1)]: nil;
            p.info_route =((char *)sqlite3_column_text(statement, 2)) ? [NSString stringWithUTF8String:(char *)sqlite3_column_text(statement, 2)]: nil;
            p.info_frequency = ((char *)sqlite3_column_text(statement, 3)) ? [NSString stringWithUTF8String:(char *)sqlite3_column_text(statement, 3)]: nil;
            p.info_timetable = ((char *)sqlite3_column_text(statement, 4)) ? [NSString stringWithUTF8String:(char *)sqlite3_column_text(statement, 4)]: nil;
            p.info_fare =sqlite3_column_int(statement, 5);
            p.info_arrivalRoute = ((char *)sqlite3_column_text(statement, 6)) ? [NSString stringWithUTF8String:(char *)sqlite3_column_text(statement, 6)]: nil;
            p.info_departureRoute = ((char *)sqlite3_column_text(statement, 7)) ? [NSString stringWithUTF8String:(char *)sqlite3_column_text(statement, 7)]: nil;
            [result addObject: p];
        }
    } else
    {
        result = nil;
        printf( "could not prepare statemnt: %s\n", sqlite3_errmsg(database) );
    }
    
    sqlite3_reset(statement);
    sqlite3_finalize(statement);
    
    sqlite3_close(database);
    
    return result;
    return 0;
}
-(NSMutableArray *) getMonthlyTicket {
    sqlite3 *database=NULL;
    sqlite3_open([[AccessDB getDBPath] UTF8String], &database);
    NSMutableArray *result = [[NSMutableArray alloc]init] ;
    
    NSString *sql = @"SELECT * FROM monthlyTicket";
    sqlite3_stmt * statement;
    
    int sqlResult = sqlite3_prepare_v2(database, [sql UTF8String], -1, &statement, NULL);
    if(sqlResult == SQLITE_OK)
    {
        while(sqlite3_step(statement) == SQLITE_ROW)
        {
            DBAttributes *p = [[DBAttributes alloc] init];
            
            p.monthlyticket_ID = sqlite3_column_int(statement, 0);
            p.monthlyticket_name =   ((char *)sqlite3_column_text(statement, 1)) ? [NSString stringWithUTF8String:(char *)sqlite3_column_text(statement, 1)]: nil;
            p.monthlyticket_location =   ((char *)sqlite3_column_text(statement, 2)) ? [NSString stringWithUTF8String:(char *)sqlite3_column_text(statement, 2)]: nil;
            [result addObject: p];
        }
    } else
    {
        result = nil;
        printf( "could not prepare statemnt: %s\n", sqlite3_errmsg(database) );
    }
    
    sqlite3_reset(statement);
    sqlite3_finalize(statement);
    
    sqlite3_close(database);
    
    return result;
}
- (NSMutableArray *) history {
    sqlite3 *database=NULL;
    sqlite3_open([[AccessDB getDBPath] UTF8String], &database);
    NSMutableArray *result = [[NSMutableArray alloc]init] ;
    NSString *sql = @"SELECT * FROM save";
    sqlite3_stmt * statement;
    int sqlResult = sqlite3_prepare_v2(database, [sql UTF8String], -1, &statement, NULL);
    if(sqlResult == SQLITE_OK)
    {
      while(sqlite3_step(statement) == SQLITE_ROW)
        {
        DBAttributes *p = [[DBAttributes alloc] init];
        p.info_fare = sqlite3_column_int(statement, 0);
        p.info_route = ((char *)sqlite3_column_text(statement, 2)) ? [NSString stringWithUTF8String:(char *)sqlite3_column_text(statement, 2)]: nil;
        p.info_arrivalRoute =((char *)sqlite3_column_text(statement, 1)) ? [NSString stringWithUTF8String:(char *)sqlite3_column_text(statement, 1)]: nil;
        [result addObject:p];
        }
    }
    else
    {
        result = nil;
        printf( "could not prepare statemnt: %s\n", sqlite3_errmsg(database) );
    }
    
    sqlite3_reset(statement);
    sqlite3_finalize(statement);
    
    sqlite3_close(database);
    
    return result;
}
- (void) addNew:(NSString *) route secondStr:(NSString *) note {
    while ([route rangeOfString:@"Hà Nội, Vietnam"].location != NSNotFound) {
        route = [route stringByReplacingCharactersInRange:[route rangeOfString:@"Hà Nội, Vietnam"] withString:@""];
    }
    while ([route rangeOfString:@"Hanoi, Vietnam"].location != NSNotFound ) {
        route = [route stringByReplacingCharactersInRange:[route rangeOfString:@"Hanoi, Vietnam"] withString:@""];
    }
    while ([note rangeOfString:@"Vietnam"].location !=NSNotFound ) {
        note = [note stringByReplacingCharactersInRange:[note rangeOfString:@"Vietnam"] withString:@""];
    }
    sqlite3 *database=NULL;
    sqlite3_open([[AccessDB getDBPath] UTF8String], &database);
    NSString *sql = [NSString stringWithFormat:@"insert into save(note, route) values(\"%@\", \"%@\")",note, route];
    const char *insert_statement = [sql UTF8String];
    sqlite3_stmt * statement;
    
    sqlite3_prepare_v2(database, insert_statement, -1, &statement, NULL);
    if(sqlite3_step(statement) == SQLITE_DONE){
        [self showUIAlertWithMessage:@"Đã lưu lại lộ trinh" andTitle:@"Message"];
    }
    else{
        [self showUIAlertWithMessage:@"Xảy ra lỗi" andTitle:@"Error"];
    }
    sqlite3_reset(statement);
    sqlite3_finalize(statement);
    sqlite3_close(database);
}
- (void) DeleteRow:(NSInteger) route {
    sqlite3 *database=NULL;
    sqlite3_open([[AccessDB getDBPath] UTF8String], &database);
    NSString *sql = [NSString stringWithFormat:@"Delete from save where save.id=\"%d\"",route];
    const char *insert_statement = [sql UTF8String];
    sqlite3_stmt * statement;
    
    sqlite3_prepare_v2(database, insert_statement, -1, &statement, NULL);
    if(sqlite3_step(statement) == SQLITE_DONE){
        [self showUIAlertWithMessage:@"Đã xoá lịch sử" andTitle:@"Message"];
    }
    else{
        [self showUIAlertWithMessage:@"Xảy ra lỗi" andTitle:@"Error"];
    }
    sqlite3_reset(statement);
    sqlite3_finalize(statement);
    sqlite3_close(database);
}
-(void) showUIAlertWithMessage:(NSString*)message andTitle:(NSString*)title{
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:title
                                                    message:message
                                                   delegate:nil
                                          cancelButtonTitle:@"OK"
                                          otherButtonTitles:nil];
    [alert show];
}


@end
