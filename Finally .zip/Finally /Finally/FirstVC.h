//
//  FirstVC.h
//  testProject
//
//  Created by artur on 2/14/14.
//  Copyright (c) 2014 artur. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FirstVC : UIViewController
@property (strong, nonatomic) NSMutableArray * arrSteps;

@end
