//
//  FifthVC.h
//  Finally
//
//  Created by Minh on 3/30/15.
//  Copyright (c) 2015 minh. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AccessDB.h"
#import "DBAttributes.h"
@interface FifthVC : UIViewController <UITableViewDataSource,UITableViewDelegate>
@property (strong, nonatomic) IBOutlet UITableView *myTableView;
@property (strong, nonatomic) DBAttributes * p;
@end
