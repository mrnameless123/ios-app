//
//  DBAttributes.m
//  Finally
//
//  Created by Minh on 3/11/15.
//  Copyright (c) 2015 minh. All rights reserved.
//

#import "DBAttributes.h"

@implementation DBAttributes

@end
