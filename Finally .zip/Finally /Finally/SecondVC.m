//
//  SevondVC.m
//  testProject
//
//  Created by artur on 2/14/14.
//  Copyright (c) 2014 artur. All rights reserved.
//

#import "SecondVC.h"
#import "AccessDB.h"
#import "DBAttributes.h"
#import "UILabel+dynamicSizeMe.h"
@interface SecondVC ()

@end

@implementation SecondVC {
    NSArray * arrayData;
    NSInteger selectedIndex;
    NSInteger prevIndex;
}


- (void)viewDidLoad
{
    [super viewDidLoad];
    AccessDB * access = [[AccessDB alloc]init];
    arrayData = [access getBusStop];
    self.title = @"Điểm dừng xe";
    [self.myTableView setBackgroundColor:[UIColor colorWithRed:0.6 green:0.9001 blue:0.4 alpha:1]];
    selectedIndex = -1;
    prevIndex = -1;
    UIBarButtonItem *button = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemSearch target:self action:@selector(ClickFind:)];
    self.navigationItem.rightBarButtonItem =  button;
}
-(void) ClickFind: (id) sender {
    [self.searchBarController becomeFirstResponder];
//  [self.myTableView setContentOffset:CGPointMake(0, -66)];
}

-(NSInteger) numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}
-(NSInteger) tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    if (tableView == self.searchDisplayController.searchResultsTableView) {
        return self.SearchResult.count;
    }
    else
    {
        return arrayData.count;
    }
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString * identify = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identify];
    if (cell==nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:identify];
    }
   if (tableView == self.searchDisplayController.searchResultsTableView)
    {
        DBAttributes *db = [self.SearchResult objectAtIndex:indexPath.row];
        cell.textLabel.text = db.stop_name;
        cell.textLabel.font = [cell.textLabel.font fontWithSize:13];
        [cell.textLabel resizeToFit];
        cell.detailTextLabel.text = [NSString stringWithFormat:@"Các tuyến đi qua: %@",db.info_vehicleID];
        cell.detailTextLabel.hidden = YES;
        cell.imageView.image = [UIImage imageNamed:@"transiticon"];
    }
    else
    {
    DBAttributes *db = nil;
     db = [arrayData objectAtIndex:indexPath.row];
        cell.textLabel.text = db.stop_name;
        cell.textLabel.font = [cell.textLabel.font fontWithSize:13];
        [cell.textLabel resizeToFit];
        cell.detailTextLabel.text = [NSString stringWithFormat:@"Các tuyến đi qua: %@",db.info_vehicleID];
        cell.detailTextLabel.hidden = YES;
        cell.imageView.image = [UIImage imageNamed:@"transiticon"];
    }
    if (selectedIndex == indexPath.row) {
        cell.detailTextLabel.hidden = NO;
        [cell.detailTextLabel resizeToFit];
    }
    return cell;
}
-(void) tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    if (selectedIndex == indexPath.row) {
        selectedIndex = -1;
        [tableView reloadRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade] ;
        return;
    }
    else if (selectedIndex != -1) {
        NSIndexPath * prevpath = [NSIndexPath indexPathForRow:selectedIndex inSection:0];
        prevIndex = selectedIndex;
        selectedIndex = indexPath.row;
        [tableView reloadRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
        [tableView reloadRowsAtIndexPaths:[NSArray arrayWithObject:prevpath] withRowAnimation:UITableViewRowAnimationFade];
        return;
    }
    selectedIndex = indexPath.row;
    [tableView reloadRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
}
- (CGFloat) tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (selectedIndex != indexPath.row) {
        return 60;
    }
    else return 120;
}

#pragma search method
- (void)filterContentForSearchText:(NSString*)searchText scope:(NSString*)scope
{
    NSPredicate *resultPredicate = [NSPredicate predicateWithFormat:@"stop_name contains[c] %@ or info_vehicleID contains[c] %@", searchText, searchText];
    _SearchResult = [NSMutableArray arrayWithArray: [arrayData filteredArrayUsingPredicate:resultPredicate]];
}
-(BOOL)searchDisplayController:(UISearchDisplayController *)controller shouldReloadTableForSearchString:(NSString *)searchString
{
    [self filterContentForSearchText:searchString scope:[[self.searchDisplayController.searchBar scopeButtonTitles] objectAtIndex:[self.searchDisplayController.searchBar selectedScopeButtonIndex]]];
    
    return YES;
}

@end
