//
//  OptionDetailViewController.h
//  Finally
//
//  Created by Minh on 3/18/15.
//  Copyright (c) 2015 minh. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DBAttributes.h"
#import <GoogleMaps/GoogleMaps.h>
@interface OptionDetailViewController : UIViewController
@property (strong, nonatomic) NSMutableArray * arrData;
@property (strong, nonatomic) NSDictionary * dictData;
@property (strong, nonatomic) DBAttributes * attribute;
@property (weak, nonatomic) GMSMarker * markerStart;
@property (weak, nonatomic) GMSMarker * markerEnd;
@property (weak, nonatomic) IBOutlet UIScrollView *myScrollView;
@property (assign, nonatomic) NSInteger flag;
@end
