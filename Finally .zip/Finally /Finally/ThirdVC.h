//
//  ThirdVC.h
//  testProject
//
//  Created by artur on 2/14/14.
//  Copyright (c) 2014 artur. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TableViewCell.h"
#import "AccessDB.h"
@interface ThirdVC : UIViewController <UITableViewDataSource, UITableViewDelegate, UISearchDisplayDelegate>
@property (strong, nonatomic) IBOutlet UITableView *myTableView;
@property (strong, nonatomic) IBOutlet UISearchBar *searchBarController;

@property (strong, nonatomic) NSArray * SearchResult;
@property (nonatomic, strong) UIMenuController *searchController;
@end
