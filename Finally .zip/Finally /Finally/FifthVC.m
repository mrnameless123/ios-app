//
//  FifthVC.m
//  Finally
//
//  Created by Minh on 3/30/15.
//  Copyright (c) 2015 minh. All rights reserved.
//

#import "FifthVC.h"
#import "UILabel+dynamicSizeMe.h"
#import "CustomAlert.h"
@interface FifthVC ()<AlertActions>

@end

@implementation FifthVC {
    NSMutableArray * arrayData;
}
@synthesize p,myTableView;
- (void)viewDidLoad
{
    [super viewDidLoad];
    self.title = @"Lịch sử tra cứu";
    [self loadData];
    [self.myTableView setBackgroundColor:[UIColor colorWithRed:0.6 green:0.9001 blue:0.4 alpha:1]];
    self.myTableView.allowsMultipleSelectionDuringEditing = NO;
    
}
- (void) viewWillAppear:(BOOL)animated  {
    [super viewWillDisappear:animated];
    [self.myTableView reloadData];
}
- (void) loadData {
    [arrayData removeAllObjects];
    AccessDB * myAccess= [[AccessDB alloc]init];
    arrayData = [myAccess history];
}

-(NSInteger) numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}
-(NSInteger) tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return arrayData.count;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString * identify = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identify];
    if (cell==nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:identify];
    }
    DBAttributes *db = nil;
    db = [arrayData objectAtIndex:indexPath.row];
    cell.textLabel.text = db.info_route;
    [cell.textLabel resizeToFit];
    [cell.textLabel setFont:[UIFont fontWithName:@"HelveticaNeue" size:12]];
//    [cell setBackgroundColor:[UIColor colorWithRed:0.6 green:0.9001 blue:0.4 alpha:1]];
//    cell.contentView.backgroundColor = [UIColor colorWithRed:0.6 green:0.9001 blue:0.4 alpha:1];
    cell.imageView.image = [UIImage imageNamed:@"transiticon"];
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    DBAttributes *db = nil;
    db = [arrayData objectAtIndex:indexPath.row];
    CustomAlert * alert = [[CustomAlert alloc]initWithMessage:[NSString stringWithFormat:@" %@ \n%@",db.info_route,db.info_arrivalRoute] andCancelButtonTitle:@"Finish" withAlertImage:nil];
      alert.delegate=self;
     [alert showAlert];
}
-(BOOL) tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    return YES;
}
-(void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    DBAttributes *db = nil;
    db = [arrayData objectAtIndex:indexPath.row];
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        AccessDB * myAccess = [[AccessDB alloc]init];
        [myAccess DeleteRow:db.info_fare];
        [self loadData];
        [self.myTableView reloadData];
    }
}
-(void)alert:(CustomAlert *)alert ButtonclickedAtIndex:(NSInteger)index{
    
    NSLog(@"Aler with tag = %ld and clicked button at %ld",(long)alert.tag,(long)index);
}

- (CGFloat) tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
          return 75;
}


@end
