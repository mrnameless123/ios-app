@interface UILabel (dynamicSizeMe)

-(float)resizeToFit;
-(float)expectedHeight;

@end
