//
//  FirstVC.m
//  testProject
//
//  Created by artur on 2/14/14.
//  Copyright (c) 2014 artur. All rights reserved.
//

#import "FirstVC.h"
#import "AFNetworking.h"
#import <GoogleMaps/GoogleMaps.h>
#import "OptionDetailViewController.h"
@interface FirstVC ()<GMSMapViewDelegate,UITableViewDelegate,UITableViewDataSource,UITextFieldDelegate>

@end

@implementation FirstVC {
    GMSMapView * mapView;
    GMSCameraPosition * camera;
    UILabel * lbl_start;
    UILabel * lbl_end;
    UITextField * tf_start;
    UITextField * tf_end;
    NSDictionary * dictStartLocation;
    NSDictionary * dictEndLocation;
    GMSMarker * markerStart;
    GMSMarker * markerEnd;
    UITableView * myTableView;
}
@synthesize arrSteps;
- (void)viewDidLoad
{
    [super viewDidLoad];
    arrSteps = [[NSMutableArray alloc]init];
    markerStart = [[GMSMarker alloc]init];
    markerEnd = [[GMSMarker alloc]init];
    myTableView = [[UITableView alloc]init];
    self.title = @"Tìm Kiếm";
    self.view.backgroundColor = [UIColor colorWithRed:0.6 green:0.9001 blue:0.4 alpha:1];
    [self AddAdress];
    camera = [[GMSCameraPosition alloc]init];
    camera = [GMSCameraPosition cameraWithLatitude:21.028667 longitude:105.852148 zoom:11.5];
    mapView = [GMSMapView mapWithFrame:CGRectMake(0, 105, 320, 375) camera:camera];
//    mapView = [GMSMapView mapWithFrame:CGRectMake(0, 43, 320, 300) camera:camera];
    mapView.camera   = camera;
    mapView.myLocationEnabled = YES;
    mapView.settings.compassButton = YES;
    mapView.delegate = self;
    [self.view addSubview:mapView];
    UIBarButtonItem *button = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemSearch target:self action:@selector(ClickFind:)];
    self.navigationItem.rightBarButtonItem =  button;
}
-(void) viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [myTableView reloadData];
    markerEnd.map = mapView;
    markerStart.map = mapView;
}
- (void) AddAdress {
    tf_start = [[UITextField alloc]initWithFrame:CGRectMake(3, 65, 315, 20)];
//    tf_start = [[UITextField alloc]initWithFrame:CGRectMake(80, 0, 230, 20)];
    tf_start.borderStyle = UITextBorderStyleRoundedRect;
    tf_start.font = [UIFont systemFontOfSize:13];
    tf_start.placeholder = @"Điểm bắt đầu";
    tf_start.autocorrectionType = UITextAutocorrectionTypeNo;
    tf_start.keyboardType = UIKeyboardTypeDefault;
    tf_start.returnKeyType = UIReturnKeyDone;
    tf_start.clearButtonMode = UITextFieldViewModeWhileEditing;
    tf_start.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    tf_start.delegate = self;
    [self.view addSubview:tf_start];
    tf_end = [[UITextField alloc]initWithFrame:CGRectMake(3, 85, 315, 20)];
//    tf_end = [[UITextField alloc]initWithFrame:CGRectMake(80, 20, 230, 20)];
    tf_end.borderStyle = UITextBorderStyleRoundedRect;
    tf_end.font = [UIFont systemFontOfSize:13];
    tf_end.placeholder = @"Điểm kết thúc";
    tf_end.autocorrectionType = UITextAutocorrectionTypeNo;
    tf_end.keyboardType = UIKeyboardTypeDefault;
    tf_end.returnKeyType = UIReturnKeyDone;
    tf_end.clearButtonMode = UITextFieldViewModeWhileEditing;
    tf_end.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    tf_end.delegate = self;
    [self.view addSubview:tf_end];
}
-(void) ClickFind: (id) sender {
    [tf_start resignFirstResponder];
    [tf_end resignFirstResponder];
    [arrSteps removeAllObjects];
    mapView = [GMSMapView mapWithFrame:CGRectMake(0, 105, 320, 275) camera:camera];
    [self.view addSubview:mapView];
    //    myTableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 455, 320, 115) style:UITableViewStylePlain];
    myTableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 380, 320, 99) style:UITableViewStylePlain];
    myTableView.delegate = self;
    myTableView.dataSource = self;
    myTableView.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:myTableView];
    NSMutableDictionary * parameters = [self sendParameterSearch:tf_start.text address2:tf_end.text];
    AFHTTPRequestOperationManager *directions = [AFHTTPRequestOperationManager manager];
    [directions GET:@"http://maps.googleapis.com/maps/api/directions/json?" parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
            [self parseResponse:responseObject];
            [myTableView reloadData];
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
         NSLog(@"Error: %@",error);
            [self showUIAlertWithMessage:@"Xảy ra lỗi" andTitle:@"Thông báo"];
    }];
}
-(NSMutableDictionary *) sendParameterSearch:(NSString *) startLocation address2:(NSString *) endLocation
{
    NSMutableDictionary *parameter=[[NSMutableDictionary alloc]init];
    [parameter setObject:[NSString stringWithString:startLocation] forKey:@"origin"];
    [parameter setObject:[NSString stringWithString:endLocation] forKey:@"destination"];
    [parameter setObject:[NSString stringWithFormat:@"true"] forKey:@"alternatives"] ;
    [parameter setObject:[NSString stringWithFormat:@"transit"] forKey:@"mode"];
    [parameter setObject:[NSString stringWithFormat:@"true"] forKey:@"stopover"];
    return parameter;
}
- (void)parseResponse:(NSDictionary *)response {
    [mapView clear];
    // mark start point
    NSMutableDictionary * parameters = [self sendParameterGeocode:tf_start.text];
    AFHTTPRequestOperationManager *start = [AFHTTPRequestOperationManager manager];
    [start GET:@"http://maps.googleapis.com/maps/api/geocode/json" parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
        dictStartLocation = [self Location:responseObject];
        markerStart.title = @"Bắt đầu";
        NSString * str_lat = [dictStartLocation objectForKey:@"lat"];
        NSString * str_lng = [dictStartLocation objectForKey:@"lng"];
        markerStart.position = CLLocationCoordinate2DMake(str_lat.floatValue, str_lng.floatValue);
        markerStart.map = mapView;
        mapView.camera= [GMSCameraPosition cameraWithTarget:CLLocationCoordinate2DMake(str_lat.floatValue, str_lng.floatValue) zoom:13];
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"Error: %@",error);
    }];
    
//    mark end point
    parameters = [self sendParameterGeocode:tf_end.text];
    AFHTTPRequestOperationManager *end = [AFHTTPRequestOperationManager manager];
    [end GET:@"http://maps.googleapis.com/maps/api/geocode/json" parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
        dictEndLocation = [self Location:responseObject];
        markerEnd.title = @"Kết Thúc";
        NSString * str_lat = [dictEndLocation objectForKey:@"lat"];
        NSString * str_lng = [dictEndLocation objectForKey:@"lng"];
        markerEnd.position = CLLocationCoordinate2DMake(str_lat.floatValue, str_lng.floatValue);
        markerEnd.map = mapView;
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"Error: %@",error);
    }];
    
    // draw route
    NSArray *routes = [response objectForKey:@"routes"];
    [arrSteps addObjectsFromArray:routes];
    if (routes.count==1) {
        NSDictionary * route = [routes lastObject];
        if (route) {
            NSString *overviewPolyline = [[route objectForKey: @"overview_polyline"] objectForKey:@"points"];
            GMSPolyline * polylineWithPath = [GMSPolyline polylineWithPath:[GMSPath pathFromEncodedPath:overviewPolyline]];
            polylineWithPath.strokeColor = [UIColor greenColor];
            polylineWithPath.strokeWidth = 3.f;
            polylineWithPath.map = mapView;
        }
    }
    else {
        NSDictionary * route = [routes firstObject];
        if (route) {
            NSString *overviewPolyline = [[route objectForKey: @"overview_polyline"] objectForKey:@"points"];
            GMSPolyline * polylineWithPath = [GMSPolyline polylineWithPath:[GMSPath pathFromEncodedPath:overviewPolyline]];
            polylineWithPath.strokeColor = [UIColor redColor];
            polylineWithPath.strokeWidth = 4.5f;
            polylineWithPath.map = mapView;
        }
        for (int i=1; i<routes.count; i++) {
            NSDictionary *route = [routes objectAtIndex:i];
            if (route) {
                NSString *overviewPolyline = [[route objectForKey: @"overview_polyline"] objectForKey:@"points"];
                GMSPolyline * polylineWithPath = [GMSPolyline polylineWithPath:[GMSPath pathFromEncodedPath:overviewPolyline]];
                polylineWithPath.strokeColor = [UIColor blueColor];
                polylineWithPath.strokeWidth = 1.5f;
                polylineWithPath.map = mapView;
            }
        }
    }

}
-(NSMutableDictionary *) sendParameterGeocode:(NSString *) address
{
    NSMutableDictionary *parameter=[[NSMutableDictionary alloc]init];
    [parameter setObject:[NSString stringWithString:address] forKey:@"address"];
    [parameter setObject:[NSString stringWithFormat:@"vn"] forKey:@"component"];
    return parameter;
}
- (NSDictionary *) Location: (NSDictionary *) response {
    NSArray *results = [response objectForKey:@"results"];
    NSDictionary *result = [results firstObject];
    NSDictionary *geometry = [result objectForKey:@"geometry"];
    NSDictionary *location = [geometry objectForKey:@"location"];
    return location;
}


#pragma mark - UITableViewDataSource
- (NSInteger)numberOfSectionsInTableView:(UITableView *)theTableView
{
    return 1;
}
- (NSInteger)tableView:(UITableView *)theTableView numberOfRowsInSection:(NSInteger)section
{
    return arrSteps.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    NSInteger count = indexPath.row;
        cell.textLabel.text = [NSString stringWithFormat:@"Phương án %i",count + 1];
    return cell;
}
- (void) tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    OptionDetailViewController * view  = [[OptionDetailViewController alloc]init];
    view.dictData = [arrSteps objectAtIndex:indexPath.row];
    view.markerEnd = markerEnd;
    view.markerStart = markerStart;
    if (indexPath.row == 0) {
        view.flag = 1;
    }
    [self.navigationController pushViewController:view animated:YES];
}
#pragma Check Network

-(void) showUIAlertWithMessage:(NSString*)message andTitle:(NSString*)title{
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:title
                                                    message:message
                                                   delegate:nil
                                          cancelButtonTitle:@"OK"
                                          otherButtonTitles:nil];
    [alert show];
}
@end
