//
//  OptionDetailViewController.m
//  Finally
//
//  Created by Minh on 3/18/15.
//  Copyright (c) 2015 minh. All rights reserved.
//

#import "OptionDetailViewController.h"
#import "UILabel+dynamicSizeMe.h"
#import "AccessDB.h"

@interface OptionDetailViewController () <GMSMapViewDelegate,UIScrollViewDelegate>

@end

@implementation OptionDetailViewController{
    GMSMapView * myMapView;
    NSMutableString * instruction;
    NSDictionary * dictStartLocation;
    NSDictionary * dictEndLocation;
    NSDictionary *polyline;
    NSString * startEnd;
    UILabel *lbl_instruction;
}

@synthesize markerStart,markerEnd;
- (void)viewDidLoad
{
    [super viewDidLoad];
    startEnd = [[NSString alloc]init];
    polyline = [[NSDictionary alloc]init];
    instruction = [[NSMutableString alloc]init];
    self.title = @"Chi tiết tìm Kiếm";
    self.arrData = [[NSMutableArray alloc]init];
    self.view.backgroundColor = [UIColor colorWithRed:0.6 green:0.9001 blue:0.4 alpha:1];
    GMSCameraPosition *   camera = [GMSCameraPosition cameraWithLatitude:markerStart.position.latitude longitude:markerStart.position.longitude zoom:11.5];
    myMapView = [GMSMapView mapWithFrame:CGRectMake(0, 50, 320, 350) camera:camera];
//    myMapView = [GMSMapView mapWithFrame:CGRectMake(0, 0, 320, 350) camera:camera];
    myMapView.camera   = camera;
    myMapView.myLocationEnabled = YES;
    myMapView.settings.compassButton = YES;
    myMapView.delegate = self;
    markerStart.map = myMapView;
    markerEnd.map   = myMapView;
    [self.view addSubview:myMapView];
    
    [self exceSteps:self.dictData];
    NSMutableString * result = [[NSMutableString alloc] init];
    for (NSObject * obj in self.arrData)
    { [result appendString:[obj description]]; }
    lbl_instruction= [[UILabel alloc] initWithFrame:CGRectMake(0, 0,self.view.frame.size.width, 50)];
    lbl_instruction.text = result;
    lbl_instruction.font = [UIFont systemFontOfSize:15];
    [lbl_instruction resizeToFit];
    
    self.automaticallyAdjustsScrollViewInsets = NO;
    [self.myScrollView addSubview:lbl_instruction];
    
    self.myScrollView.delegate = self;
    [self drawRoute];
    
    UIBarButtonItem *button = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemSave target:self action:@selector(ClickSave:)];
    self.navigationItem.rightBarButtonItem =  button;
}
- (void) viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [myMapView reloadInputViews];
    [self drawRoute];
    self.myScrollView.contentSize = CGSizeMake(320, lbl_instruction.frame.size.height + 5);
    
}

- (void) ClickSave: (id) sender {
    AccessDB * access = [[AccessDB alloc] init];
    NSMutableString * result = [[NSMutableString alloc] init];
    for (NSObject * obj in self.arrData)
    { [result appendString:[obj description]]; }
    [access addNew:startEnd secondStr:result];
}

-(void) drawRoute {
    NSString *overviewPolyline = [polyline objectForKey:@"points"];
    GMSPolyline * polylineWithPath = [GMSPolyline polylineWithPath:[GMSPath pathFromEncodedPath:overviewPolyline]];
    if (self.flag == 1) {
        polylineWithPath.strokeColor = [UIColor redColor];
    }
    else {
        polylineWithPath.strokeColor = [UIColor blueColor];}
    polylineWithPath.strokeWidth = 4.5f;
    polylineWithPath.map = myMapView;
}
- (void) exceSteps:(NSDictionary *) response {
    NSArray *legs = [response objectForKey: @"legs"] ;
    polyline  = [response objectForKey:@"overview_polyline"];
    NSDictionary * temp = [legs objectAtIndex:0];
    NSArray * steps = [temp objectForKey:@"steps"];
    NSString *end = [temp objectForKey:@"end_address"];
    NSString * start = [temp objectForKey:@"start_address"];
    startEnd = [NSString stringWithFormat:@"from: %@ to: %@", start,end];
    NSMutableString * duration = [[temp objectForKey:@"duration"] objectForKey:@"text"];
    duration = [NSMutableString stringWithFormat:@"- Thời gian thực hiện lộ trình %@",duration];
    [self.arrData addObject:duration];
    for (int i = 0 ; i<steps.count; i++) {
        temp = [steps objectAtIndex:i];
        NSString * travel_mode = [temp objectForKey:@"travel_mode"];
        if ( [travel_mode isEqualToString:@"TRANSIT"] == YES ) {
            NSString * name = [[[temp objectForKey:@"transit_details"] objectForKey:@"line"] objectForKey:@"name"];
            NSString *arrival_stop_name = [[[temp objectForKey:@"transit_details"]  objectForKey:@"arrival_stop"] objectForKey:@"name"];
            NSString * duration = [[temp objectForKey:@"duration"] objectForKey:@"text"];
            instruction = [NSMutableString stringWithFormat:@"\n- Bắt tuyến bus %@ xuống xe tại: %@\t thời gian đi:%@", name,arrival_stop_name, duration];
                [self.arrData addObject:instruction];
        }
        else{
            NSString * html_instructions = [temp objectForKey:@"html_instructions"];
            NSString * distance = [[temp objectForKey:@"distance"] objectForKey:@"text"];
            NSString * duration = [[temp objectForKey:@"duration"] objectForKey:@"text"];
            instruction = [NSMutableString stringWithFormat:@"\n-%@ khoảng cách:%@ thời gian: %@ ", html_instructions, distance, duration];
            [self.arrData addObject:instruction];
        }
    }
}

@end
