//
//  DBAttributes.h
//  Finally
//
//  Created by Minh on 3/11/15.
//  Copyright (c) 2015 minh. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DBAttributes : NSObject
@property (strong, nonatomic) NSString * info_vehicleID;
@property (strong, nonatomic) NSString * info_company;
@property (strong, nonatomic) NSString * info_route;
@property (strong, nonatomic) NSString * info_frequency;
@property (strong, nonatomic) NSString * info_timetable;
@property (assign, nonatomic) NSInteger info_fare;
@property (strong, nonatomic) NSString * info_arrivalRoute;
@property (strong, nonatomic) NSString * info_departureRoute;

@property (assign, nonatomic) NSInteger stop_ID;
@property (strong, nonatomic) NSString * stop_name;

@property (assign, nonatomic) NSInteger monthlyticket_ID;
@property (strong, nonatomic) NSString * monthlyticket_location;
@property (strong, nonatomic) NSString * monthlyticket_name;

@end
