//
//  TableViewCell.m
//  Finally
//
//  Created by Minh on 3/11/15.
//  Copyright (c) 2015 minh. All rights reserved.
//

#import "TableViewCell.h"

@implementation TableViewCell
@synthesize lbl_busID,lbl_routeInfo;
- (void)awakeFromNib
{
//    lbl_routeInfo.backgroundColor = [UIColor colorWithRed:0.6 green:0.9001 blue:0.4 alpha:1];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
