//
//  ThirdVC.m
//  testProject
//
//  Created by artur on 2/14/14.
//  Copyright (c) 2014 artur. All rights reserved.
//

#import "ThirdVC.h"
#import "DBAttributes.h"
#import "TableViewCell.h"
#import "DetailBusInfoViewController.h"
@interface ThirdVC ()

@end

@implementation ThirdVC {
    NSMutableArray * arrayData;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    AccessDB * access = [[AccessDB alloc]init];
    arrayData = [access getBusInfo];
    
    self.title = @"Tra cứu tuyến xe bus";
    UIBarButtonItem *button = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemSearch target:self action:@selector(ClickFind:)];
    self.navigationItem.rightBarButtonItem =  button;
}
-(void) ClickFind: (id) sender {
    [self.searchBarController becomeFirstResponder];
}
-(NSInteger) numberOfSectionsInTableView:(UITableView *)tableView   {
    return 1;
}
-(NSInteger) tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (tableView == self.searchDisplayController.searchResultsTableView) {
        return self.SearchResult.count;
    }
    else
    {
        return arrayData.count;
    }
}
-(UITableViewCell *) tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString * identify = @"Cell";
    TableViewCell * cell = (TableViewCell *) [tableView dequeueReusableCellWithIdentifier:identify];
    if (cell == nil) {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"TableViewCell" owner:self options:nil];
        cell= [nib objectAtIndex:0];
    }
    if (tableView == self.searchDisplayController.searchResultsTableView)
    {
        DBAttributes *db = [self.SearchResult objectAtIndex:indexPath.row];
        cell.lbl_busID.text = db.info_vehicleID;
        cell.lbl_routeInfo.text = [NSString stringWithFormat:@"%@",db.info_route];
    }
    else
    {
        DBAttributes *db = nil;
        db = [arrayData objectAtIndex:indexPath.row];
        cell.lbl_busID.text = db.info_vehicleID;
        cell.lbl_routeInfo.text = [NSString stringWithFormat:@"%@",db.info_route];
    }
    return cell;

}
-(CGFloat) tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 37;
}
- (void) tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {    
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    DetailBusInfoViewController * detail   = [[DetailBusInfoViewController alloc]init];
    DBAttributes * p= [[DBAttributes alloc]init];
    if (tableView == self.searchDisplayController.searchResultsTableView) {
        p = self.SearchResult[indexPath.row];
    }
    else {
        p = arrayData[indexPath.row];
    }
    detail.myDBAttribute = p;
    [self.navigationController pushViewController:detail animated:YES];
}
#pragma search method
- (void)filterContentForSearchText:(NSString*)searchText scope:(NSString*)scope
{
    NSPredicate *resultPredicate = [NSPredicate predicateWithFormat:@"info_vehicleID contains[c] %@ or info_route contains[c] %@", searchText,searchText];
    _SearchResult = [NSMutableArray arrayWithArray: [arrayData filteredArrayUsingPredicate:resultPredicate]];
}
-(BOOL)searchDisplayController:(UISearchDisplayController *)controller shouldReloadTableForSearchString:(NSString *)searchString
{
    [self filterContentForSearchText:searchString scope:[[self.searchDisplayController.searchBar scopeButtonTitles] objectAtIndex:[self.searchDisplayController.searchBar selectedScopeButtonIndex]]];
    
    return YES;
}
@end
