//
//  DetailBusInfoViewController.h
//  Finally
//
//  Created by Minh on 3/11/15.
//  Copyright (c) 2015 minh. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DBAttributes.h"
@interface DetailBusInfoViewController : UIViewController 
@property (strong, nonatomic) IBOutlet UILabel *lbl_arrival;
@property (strong, nonatomic) IBOutlet UILabel *lbl_departure;

@property (strong, nonatomic) IBOutlet UIScrollView *scrollView;

@property (strong, nonatomic) DBAttributes * myDBAttribute;

@property (strong, nonatomic) IBOutlet UILabel *lbl_x;

@property (strong, nonatomic) IBOutlet UILabel *lbl_route;
@property (strong, nonatomic) IBOutlet UILabel *lbl_freq;
@property (strong, nonatomic) IBOutlet UILabel *lbl_fare;
@property (strong, nonatomic) IBOutlet UILabel *lbl_company;
@property (strong, nonatomic) IBOutlet UILabel *lbl_schedule;

@end
