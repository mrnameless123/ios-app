//
//  FourthVC.m
//  Finally
//
//  Created by Minh on 3/11/15.
//  Copyright (c) 2015 minh. All rights reserved.
//

#import "FourthVC.h"
#import "AccessDB.h"
#import "DBAttributes.h"
#import "UILabel+dynamicSizeMe.h"
@interface FourthVC ()

@end

@implementation FourthVC
{
    NSArray * arrayData;
    NSInteger selectedIndex;
    NSInteger prevIndex;

}

- (void)viewDidLoad
{
    [super viewDidLoad];
    AccessDB * access = [[AccessDB alloc]init];
    arrayData = [access getMonthlyTicket];
    self.title = @"Điểm bán vé tháng";
    [self.myTableView setBackgroundColor:[UIColor colorWithRed:0.6 green:0.9001 blue:0.4 alpha:1]];
    selectedIndex = -1;
    prevIndex = -1;
    UIBarButtonItem *button = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemSearch target:self action:@selector(ClickFind:)];
    self.navigationItem.rightBarButtonItem =  button;

}
-(void) ClickFind: (id) sender {
    [self.searchBarController becomeFirstResponder];
}
-(NSInteger) numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}
-(NSInteger) tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    if (tableView == self.searchDisplayController.searchResultsTableView) {
        return self.SearchResult.count;
    }
    else
    {
        return arrayData.count;
    }
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString * identify = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identify];
    if (cell==nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:identify];
    }
    if (tableView == self.searchDisplayController.searchResultsTableView)
    {
        DBAttributes *db = [self.SearchResult objectAtIndex:indexPath.row];
        cell.textLabel.text = db.monthlyticket_name;
        cell.textLabel.font = [cell.textLabel.font fontWithSize:12];
        [cell.textLabel resizeToFit];
        cell.detailTextLabel.text = [NSString stringWithFormat:@"Lịch làm việc: %@",db.monthlyticket_location];
        cell.detailTextLabel.hidden = YES;
        [cell.detailTextLabel resizeToFit];
        cell.contentView.backgroundColor = [UIColor colorWithRed:0.6 green:0.9001 blue:0.4 alpha:1];
        cell.imageView.image = [UIImage imageNamed:@"transiticon"];
    }
    else
    {
        DBAttributes *db = nil;
        db = [arrayData objectAtIndex:indexPath.row];
        cell.textLabel.text = db.monthlyticket_name;
        cell.textLabel.font = [cell.textLabel.font fontWithSize:12];
        [cell.textLabel resizeToFit];
        cell.detailTextLabel.text = [NSString stringWithFormat:@"Lịch làm việc: %@",db.monthlyticket_location];
        cell.detailTextLabel.hidden = YES;
        [cell.detailTextLabel resizeToFit];
//        cell.contentView.backgroundColor = [UIColor colorWithRed:0.6 green:0.9001 blue:0.4 alpha:1];
        cell.imageView.image = [UIImage imageNamed:@"transiticon"];
    }
    if (selectedIndex == indexPath.row) {
        cell.detailTextLabel.hidden = NO;
    }
    return cell;

}

-(void) tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    if (selectedIndex == indexPath.row) {
        selectedIndex = -1;
        [tableView reloadRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade] ;
        return;
    }
    else if (selectedIndex != -1) {
        NSIndexPath * prevpath = [NSIndexPath indexPathForRow:selectedIndex inSection:0];
        prevIndex = selectedIndex;
        selectedIndex = indexPath.row;
        [tableView reloadRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
        [tableView reloadRowsAtIndexPaths:[NSArray arrayWithObject:prevpath] withRowAnimation:UITableViewRowAnimationFade];
        return;
    }
    selectedIndex = indexPath.row;
    [tableView reloadRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
}

- (CGFloat) tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (selectedIndex != indexPath.row) {
        return 65;
    }
    else return 120;
}

#pragma search method
- (void)filterContentForSearchText:(NSString*)searchText scope:(NSString*)scope
{
    NSPredicate *resultPredicate = [NSPredicate predicateWithFormat:@"monthlyticket_name contains[c] %@", searchText];
    _SearchResult = [NSMutableArray arrayWithArray: [arrayData filteredArrayUsingPredicate:resultPredicate]];
}
-(BOOL)searchDisplayController:(UISearchDisplayController *)controller shouldReloadTableForSearchString:(NSString *)searchString
{
    [self filterContentForSearchText:searchString scope:[[self.searchDisplayController.searchBar scopeButtonTitles] objectAtIndex:[self.searchDisplayController.searchBar selectedScopeButtonIndex]]];
    
    return YES;
}

@end
