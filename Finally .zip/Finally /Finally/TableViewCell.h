//
//  TableViewCell.h
//  Finally
//
//  Created by Minh on 3/11/15.
//  Copyright (c) 2015 minh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TableViewCell : UITableViewCell

@property (strong, nonatomic) IBOutlet UILabel *lbl_busID;
@property (strong, nonatomic) IBOutlet UILabel *lbl_routeInfo;

@end
