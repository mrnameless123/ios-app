//
//  AccessDB.h
//  Given Data
//
//  Created by Minh on 2/11/15.
//  Copyright (c) 2015 Minh. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <sqlite3.h>
//#import "PersonContact.h"
@interface AccessDB : NSObject
+ (NSString *) getDBPath;
+ (void) copyDatabaseIfNeeded;

-(NSArray *) getBusStop ;
-(NSMutableArray *) getBusInfo ;
-(NSMutableArray *) getMonthlyTicket;
- (void) addNew:(NSString *) route secondStr:(NSMutableString *) note ;
- (void) DeleteRow:(NSInteger) route;
- (NSMutableArray *) history;
@end
